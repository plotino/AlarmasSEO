// State Management
const STATE_KEY = 'gsc_analyzer_data';
const appState = {
    rawData: [],
    processedData: {},
    alarms: {
        sequential: [],
        yoy: []
    },
    meta: {
        dMax: null,
        monthsMap: [] // Ordered list of 'YYYY-MM' strings available
    }
};

// DOM Elements
const views = {
    upload: document.getElementById('view-upload'),
    dashboard: document.getElementById('view-dashboard')
};

const ui = {
    dropZone: document.getElementById('drop-zone'),
    fileInput: document.getElementById('file-input'),
    uploadError: document.getElementById('upload-error'),
    navDashboard: document.getElementById('nav-dashboard'),
    navUpload: document.getElementById('nav-upload'),
    btnReset: document.getElementById('btn-reset'),

    // Stats
    statSequential: document.getElementById('stat-sequential-count'),
    statYoy: document.getElementById('stat-yoy-count'),
    statTotal: document.getElementById('stat-total-urls'),
    analysisPeriod: document.getElementById('analysis-period'),

    // Tables
    tableSequential: document.querySelector('#table-sequential tbody'),
    tableYoy: document.querySelector('#table-yoy tbody'),

    // Tabs
    tabBtns: document.querySelectorAll('.tab-btn'),
    tabContents: document.querySelectorAll('.tab-content'),

    // Modal
    modal: document.getElementById('detail-modal'),
    modalTitle: document.getElementById('modal-title'),
    modalClose: document.getElementById('modal-close'),
    chartCanvas: document.getElementById('detail-chart')
};

let detailChart = null;

// --- Initialization ---
function init() {
    setupEventListeners();
    checkSession();
}

function checkSession() {
    const saved = sessionStorage.getItem(STATE_KEY);
    if (saved) {
        try {
            const parsed = JSON.parse(saved);
            loadState(parsed);
            showDashboard();
        } catch (e) {
            console.error('Error loading session', e);
            sessionStorage.removeItem(STATE_KEY);
        }
    }
}

function setupEventListeners() {
    // Navigation
    ui.navDashboard.addEventListener('click', (e) => {
        e.preventDefault();
        if (appState.rawData.length > 0) showDashboard();
    });

    ui.navUpload.addEventListener('click', (e) => {
        e.preventDefault();
        showUpload();
    });

    ui.btnReset.addEventListener('click', resetApp);

    // Upload
    ui.dropZone.addEventListener('click', () => ui.fileInput.click());
    ui.dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        ui.dropZone.classList.add('dragover');
    });
    ui.dropZone.addEventListener('dragleave', () => ui.dropZone.classList.remove('dragover'));
    ui.dropZone.addEventListener('drop', handleDrop);
    ui.fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));

    // Tabs
    ui.tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            ui.tabBtns.forEach(b => b.classList.remove('active'));
            ui.tabContents.forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.tab).classList.add('active');
        });
    });

    // Modal
    ui.modalClose.addEventListener('click', () => ui.modal.classList.add('hidden'));
    ui.modal.addEventListener('click', (e) => {
        if (e.target === ui.modal) ui.modal.classList.add('hidden');
    });
}

// --- File Handling ---
function handleDrop(e) {
    e.preventDefault();
    ui.dropZone.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    handleFile(file);
}

function handleFile(file) {
    if (!file) return;
    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
        showError('Por favor sube un archivo CSV válido.');
        return;
    }

    Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
            if (validateCSV(results.meta.fields)) {
                processData(results.data);
            } else {
                showError('El CSV no tiene las columnas requeridas: Page, Date, Clicks');
            }
        },
        error: (err) => showError('Error al leer el archivo: ' + err.message)
    });
}

function validateCSV(fields) {
    const required = ['date', 'clicks'];
    // Allow 'Page' or 'URL'
    const hasPage = fields.some(f => f.toLowerCase() === 'page' || f.toLowerCase() === 'url');
    const hasOthers = required.every(r => fields.some(f => f.toLowerCase() === r));
    return hasPage && hasOthers;
}

function showError(msg) {
    ui.uploadError.textContent = msg;
    ui.uploadError.classList.remove('hidden');
    setTimeout(() => ui.uploadError.classList.add('hidden'), 5000);
}

// --- Data Processing (Core Logic) ---
function processData(rows) {
    // 1. Clean & Sort
    const cleanRows = rows.map(r => {
        const page = r['Page'] || r['page'] || r['URL'] || r['url'];
        const dateStr = r['Date'] || r['date'];
        const clicks = parseInt(r['Clicks'] || r['clicks'], 10);

        if (!page || !dateStr || isNaN(clicks)) return null;
        return { page, date: new Date(dateStr), clicks };
    }).filter(r => r !== null && r.clicks >= 0)
        .sort((a, b) => a.date - b.date);

    if (cleanRows.length === 0) {
        showError('No se encontraron datos válidos.');
        return;
    }

    // 2. Identify D_max and Cutoff
    const dMax = cleanRows[cleanRows.length - 1].date;
    const isFullMonth = isLastDayOfMonth(dMax);

    // Determine Base Month (M0)
    // If Dmax is full month (e.g. 31 Jan), M0 is Jan. 
    // If Dmax is partial (e.g. 15 Jan), M0 is Dec.
    let m0Date = new Date(dMax);
    if (!isFullMonth) {
        // Go back to previous month
        m0Date.setMonth(m0Date.getMonth() - 1);
        m0Date.setDate(1); // normalized
    }

    // 3. Aggregate by Month
    const monthsMap = new Set();
    const agg = {}; // { URL: { "YYYY-MM": clicks, ... } }

    cleanRows.forEach(r => {
        const mKey = getMonthKey(r.date);

        // Only aggregate months <= m0Date (ignore partial future/current month)
        // Wait, SRS says: "Visualización: resaltar... mes parcial excluido". 
        // So we NEED partial data for the chart, but EXCLUDE it for Alarms.

        monthsMap.add(mKey);

        if (!agg[r.page]) agg[r.page] = {};
        if (!agg[r.page][mKey]) agg[r.page][mKey] = 0;
        agg[r.page][mKey] += r.clicks;
    });

    const sortedMonths = Array.from(monthsMap).sort();

    // 4. Run Alarm Logic
    // --- IMPROVEMENT: Data Homogeneity ---
    // Filter out URLs that don't have data in the base month (m0Key)
    const m0Key = getMonthKey(m0Date);
    const homogeneousAgg = {};
    Object.entries(agg).forEach(([url, monthlyData]) => {
        if (monthlyData[m0Key] !== undefined) {
            homogeneousAgg[url] = monthlyData;
        }
    });

    const alarms = detectAlarms(homogeneousAgg, sortedMonths, m0Date);
    const topAlarms = detectTopPagesAlarms(homogeneousAgg, alarms, sortedMonths, m0Date);

    // Save State
    appState.rawData = cleanRows; // Keep for charts
    appState.processedData = homogeneousAgg;
    appState.alarms = alarms;
    appState.topAlarms = topAlarms;
    appState.meta.dMax = dMax;
    appState.meta.monthsMap = sortedMonths;
    appState.meta.m0Key = m0Key;

    sessionStorage.setItem(STATE_KEY, JSON.stringify(appState));

    showDashboard();
}

/**
 * Identifies Top Pages (historically) that have BOTH sequential and yoy alarms
 */
function detectTopPagesAlarms(aggData, alarms, sortedMonths, m0Date) {
    // Calculate total clicks for weight
    const totals = Object.entries(aggData).map(([url, data]) => ({
        url,
        total: Object.values(data).reduce((a, b) => a + b, 0)
    })).sort((a, b) => b.total - a.total);

    // Define "Top" as top 20 or top 10%
    const limit = Math.max(10, Math.ceil(totals.length * 0.1));
    const topUrls = new Set(totals.slice(0, limit).map(t => t.url));

    const seqUrls = new Set(alarms.sequential.map(a => a.url));
    const yoyUrls = new Set(alarms.yoy.map(a => a.url));

    return totals
        .filter(t => topUrls.has(t.url) && seqUrls.has(t.url) && yoyUrls.has(t.url))
        .map(t => {
            const seq = alarms.sequential.find(a => a.url === t.url);
            const yoy = alarms.yoy.find(a => a.url === t.url);
            return {
                url: t.url,
                totalClicks: t.total,
                dropPct: seq.dropPct,
                diff: yoy.diff
            };
        });
}

function isLastDayOfMonth(date) {
    const nextDay = new Date(date);
    nextDay.setDate(date.getDate() + 1);
    return nextDay.getDate() === 1;
}

function getMonthKey(date) {
    return date.toISOString().slice(0, 7); // YYYY-MM
}

function detectAlarms(aggData, sortedMonths, m0Date) {
    const m0Key = getMonthKey(m0Date);
    const m0Index = sortedMonths.indexOf(m0Key);

    // If we don't have at least M-2 (3 months total), we can't do Sequential
    const hasSequentialData = m0Index >= 2;

    const seqAlarms = [];
    const yoyAlarms = [];

    // Keys for Sequential
    const k0 = m0Key;
    const k1 = hasSequentialData ? sortedMonths[m0Index - 1] : null;
    const k2 = hasSequentialData ? sortedMonths[m0Index - 2] : null;

    Object.entries(aggData).forEach(([url, data]) => {
        // Sequential Drop: M0 < M-1 < M-2
        if (hasSequentialData) {
            const c0 = data[k0] || 0;
            const c1 = data[k1] || 0;
            const c2 = data[k2] || 0;

            if (c0 > 0 && c0 < c1 && c1 < c2) {
                // Calculate drop % (M0 vs M2)
                const dropPct = c2 > 0 ? ((c2 - c0) / c2) * 100 : 0;
                seqAlarms.push({
                    url,
                    c0, c1, c2,
                    dropPct: dropPct.toFixed(1)
                });
            }
        }

        // YoY Drop: Sum(Last 3) < Sum(Same 3 Last Year)
        // Need indexes for M-12, M-13, M-14 relative to M0
        // Logic: M0 corresponds to sortedMonths[m0Index]
        // M-12 must be present in sortedMonths (?)
        // Better: calculate YYYY-MM keys for last year
        if (hasSequentialData) { // Need current window first
            const currentSum = (data[k0] || 0) + (data[k1] || 0) + (data[k2] || 0);

            // Generate Last Year Keys
            const prevYearKeys = [0, 1, 2].map(offset => {
                const d = new Date(m0Date);
                d.setMonth(d.getMonth() - offset);
                d.setFullYear(d.getFullYear() - 1);
                return getMonthKey(d);
            });

            // Check if we have data for ANY of those months (strict YoY requires data?)
            // Usually assumes data exists or is 0.
            const prevSum = prevYearKeys.reduce((acc, k) => acc + (data[k] || 0), 0);

            if (c0 > 0 && currentSum < prevSum && prevSum > 0) {
                yoyAlarms.push({
                    url,
                    currentSum,
                    prevSum,
                    diff: prevSum - currentSum,
                    c0 // Keep base month clicks for sorting
                });
            }
        }
    });

    return {
        sequential: seqAlarms.sort((a, b) => b.c0 - a.c0),
        yoy: yoyAlarms.sort((a, b) => b.currentSum - a.currentSum)
    };
}

// --- UI Rendering ---
function showUpload() {
    views.upload.classList.remove('hidden');
    views.dashboard.classList.add('hidden');
    ui.navUpload.classList.add('active');
    ui.navDashboard.classList.remove('active');
}

function showDashboard() {
    views.upload.classList.add('hidden');
    views.dashboard.classList.remove('hidden');
    ui.navUpload.classList.remove('active');
    ui.navDashboard.classList.add('active');

    // Update Stats
    ui.statSequential.textContent = appState.alarms.sequential.length;
    ui.statYoy.textContent = appState.alarms.yoy.length;
    ui.statTotal.textContent = Object.keys(appState.processedData).length;
    ui.analysisPeriod.textContent = `Mes Base: ${appState.meta.m0Key}`;

    // Render Sections
    renderTopPagesSection();
    renderSequentialTable();
    renderYoyTable();

    // Update Headers for Months
    const m0Idx = appState.meta.monthsMap.indexOf(appState.meta.m0Key);
    if (m0Idx >= 2) {
        document.getElementById('th-month-0').innerHTML = `Clics ${appState.meta.monthsMap[m0Idx]} <i class="ph ph-caret-up-down"></i>`;
        document.getElementById('th-month-1').innerHTML = `Clics ${appState.meta.monthsMap[m0Idx - 1]} <i class="ph ph-caret-up-down"></i>`;
        document.getElementById('th-month-2').innerHTML = `Clics ${appState.meta.monthsMap[m0Idx - 2]} <i class="ph ph-caret-up-down"></i>`;

        // Update YoY headers
        const yoyCurr = document.getElementById('th-yoy-curr');
        const yoyPrev = document.getElementById('th-yoy-prev');
        const yoyDiff = document.getElementById('th-yoy-diff');
        if (yoyCurr) yoyCurr.innerHTML = `Trimestre Actual <i class="ph ph-caret-up-down"></i>`;
        if (yoyPrev) yoyPrev.innerHTML = `Trimestre Pasado <i class="ph ph-caret-up-down"></i>`;
        if (yoyDiff) yoyDiff.innerHTML = `Dif. Absoluta <i class="ph ph-caret-up-down"></i>`;

        const seqDrop = document.getElementById('th-seq-drop');
        if (seqDrop) seqDrop.innerHTML = `Caída % <i class="ph ph-caret-up-down"></i>`;
    }
}

function renderTopPagesSection() {
    const container = document.getElementById('top-pages-alert-container');
    if (!container) return;

    if (!appState.topAlarms || appState.topAlarms.length === 0) {
        container.innerHTML = `
            <div class="empty-state-mini">
                <i class="ph ph-check-circle"></i>
                <p>No se detectan URLs Top con doble señal negativa.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = appState.topAlarms.map(item => `
        <div class="top-alert-card">
            <div class="top-alert-info">
                <div class="top-alert-title"><a href="${item.url}" target="_blank" class="url-link">${item.url}</a></div>
                <div class="top-alert-meta">Tráfico Histórico: ${item.totalClicks.toLocaleString()} clics</div>
            </div>
            <div class="top-alert-stats">
                <span class="badge danger" title="Bajada porcentual del último trimestre">
                    <i class="ph ph-trend-down"></i> Bajada % Últ. Trimestre: -${item.dropPct}%
                </span>
                <span class="badge danger" title="Clics totales que se pierden en la comparativa YoY">
                    <i class="ph ph-calendar-x"></i> Clics perdidos YoY: -${item.diff.toLocaleString()}
                </span>
            </div>
            <button class="action-btn" onclick="window.viewDetail('${item.url}')">
                <i class="ph ph-eye"></i>
            </button>
        </div>
    `).join('');
}

function renderSequentialTable() {
    ui.tableSequential.innerHTML = appState.alarms.sequential.map(item => `
        <tr>
            <td>
                <div style="font-weight:500;"><a href="${item.url}" target="_blank" class="url-link">${item.url}</a></div>
            </td>
            <td class="text-right">${item.c2}</td>
            <td class="text-right">${item.c1}</td>
            <td class="text-right"><strong>${item.c0}</strong></td>
            <td class="text-right">
                <span style="color:var(--danger-color); background:var(--danger-bg); padding:2px 6px; border-radius:4px; font-size:12px;">
                    -${item.dropPct}%
                </span>
            </td>
            <td>
                <button class="action-btn" onclick="window.viewDetail('${item.url}')">
                    <i class="ph ph-chart-line-up"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function renderYoyTable() {
    ui.tableYoy.innerHTML = appState.alarms.yoy.map(item => `
        <tr>
             <td>
                <div style="font-weight:500;"><a href="${item.url}" target="_blank" class="url-link">${item.url}</a></div>
            </td>
            <td class="text-right">${item.prevSum}</td>
            <td class="text-right">${item.currentSum}</td>
            <td class="text-right">
                <span style="color:var(--danger-color); font-weight:500;">
                    -${item.diff}
                </span>
            </td>
            <td>
                <button class="action-btn" onclick="window.viewDetail('${item.url}')">
                    <i class="ph ph-chart-line-up"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function loadState(state) {
    // Rehydrate Dates
    if (state.rawData) state.rawData.forEach(r => r.date = new Date(r.date));
    if (state.meta && state.meta.dMax) state.meta.dMax = new Date(state.meta.dMax);
    appState.rawData = state.rawData || [];
    appState.processedData = state.processedData || {};
    appState.alarms = state.alarms || { sequential: [], yoy: [] };
    appState.topAlarms = state.topAlarms || [];
    appState.meta = state.meta || {};
}

// Global for inline onclick
window.viewDetail = function (url) {
    ui.modal.classList.remove('hidden');
    ui.modalTitle.innerHTML = `<a href="${url}" target="_blank" class="url-link">${url}</a>`;
    renderChart(url);
}

function resetApp() {
    sessionStorage.removeItem(STATE_KEY);
    appState.rawData = [];
    appState.processedData = {};
    window.location.reload();
}

// --- Sorting Logic ---
let currentSort = { table: null, col: null, dir: 'desc' };

window.sortTable = function (table, col) {
    const alarms = appState.alarms[table];
    if (!alarms) return;

    if (currentSort.table === table && currentSort.col === col) {
        currentSort.dir = currentSort.dir === 'desc' ? 'asc' : 'desc';
    } else {
        currentSort.table = table;
        currentSort.col = col;
        currentSort.dir = 'desc';
    }

    alarms.sort((a, b) => {
        let valA = a[col];
        let valB = b[col];

        // Handle numeric strings if any
        if (typeof valA === 'string' && !isNaN(valA)) valA = parseFloat(valA);
        if (typeof valB === 'string' && !isNaN(valB)) valB = parseFloat(valB);

        if (currentSort.dir === 'desc') return valB > valA ? 1 : -1;
        return valA > valB ? 1 : -1;
    });

    if (table === 'sequential') renderSequentialTable();
    else renderYoyTable();
}

function renderChart(url) {
    const ctx = ui.chartCanvas.getContext('2d');
    if (detailChart) detailChart.destroy();

    const m0Key = appState.meta.m0Key;
    const m0Idx = appState.meta.monthsMap.indexOf(m0Key);

    // Period 1: Last 3 months (current)
    const currentPeriodKeys = [
        appState.meta.monthsMap[m0Idx - 2],
        appState.meta.monthsMap[m0Idx - 1],
        appState.meta.monthsMap[m0Idx]
    ];

    // Period 2: Same 3 months (previous year)
    const prevYearKeys = currentPeriodKeys.map(k => {
        const [year, month] = k.split('-');
        return `${parseInt(year) - 1}-${month}`;
    });

    const currentValues = currentPeriodKeys.map(k => appState.processedData[url][k] || 0);
    const prevValues = prevYearKeys.map(k => appState.processedData[url][k] || 0);

    const labels = currentPeriodKeys;

    detailChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Año Actual',
                    data: currentValues,
                    borderColor: '#1E5F46',
                    backgroundColor: 'rgba(30, 95, 70, 0.1)',
                    tension: 0.3,
                    fill: false,
                    pointBackgroundColor: '#1E5F46'
                },
                {
                    label: 'Año Anterior',
                    data: prevValues,
                    borderColor: '#E74C3C',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    tension: 0.3,
                    fill: false,
                    pointBackgroundColor: '#E74C3C',
                    borderDash: [5, 5]
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Clics' }
                }
            }
        }
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', init);
